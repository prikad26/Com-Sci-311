/**
 * Team members:
 * 
 * @author KayAnne Bryant
 * @author Priyanka Kadaganchi
 *
 *  IntervalTreap class represents an interval treap.
 **/
import java.util.*;

public class IntervalTreap {
	//private variables are loacted here
	private Node root;
	private int size;
	private int height;

	/**
	* Constructor with no parameters
	* Runtime: Constant
	**/
	public IntervalTreap() {
		this.root = null;
		this.size = 0;
		this.height = 0;
	}

	/**
	 * Get Root Method
	 * Returns a reference to the root node.
	 * Runtime: Constant
	 * 
	 * @return root
	 */
	public Node getRoot() {
		return this.root;
	}

	/**
	 * Get Size Method
	 * Returns the number of nodes in the treap.
	 * Runtime: Constant
	 * 
	 * @return size
	 */
	public int getSize() {
		return this.size;
	}

	public void setHeight(int h) {
		this.height = h;
	}

	/**
	 * Get Height Method
	 * Returns the height of the treap.
	 * Runtime: Constant
	 * 
	 * @return height
	 */
	public int getHeight() {
		return this.height;
	}

	/*
	 * Interval Insert Method
	 * Adds node z, whose interval interv attribute references 
	 * an Interval object, to the interval treap.
	 * This operation must maintain the required interval treap properties
	 * Runtime: O(logn) on an n-node interval treap
	 * 
	 */
	public void intervalInsert(Node z) {
		z.setIMax(z.getInterv().getHigh());
		this.size++;

		Node y = null;
		Node x = this.root;
		while (x != null) {
			y = x;
			x.setIMax(Math.max(x.getIMax(), z.getInterv().getHigh()));
			if (z.getInterv().getLow() < x.getInterv().getLow()) {
				x = x.getLeft();
			} else {
				x = x.getRight();
			}
		}
		z.setParent(y);
		if (y == null) 
		{
		    this.root = z;
		} 
		else if (z.getInterv().getLow() < y.getInterv().getLow()) 
		{
		   y.setLeft(z);
		} 
		else 
		{ 
			y.setRight(z); // same low interval goes on right
		}

		while (z.getParent() != null && z.getPriority() < z.getParent().getPriority()) 
		{
			if (z == z.getParent().getRight())
			{
			    leftRotate(z.getParent());
			} 
			else 
			{
			    rightRotate(z.getParent());
			}
		}

		updateHeights(z);  //Updates the height

		if (this.root != null) {
			this.height = this.root.getHeight();
		} else {
			this.height = 0;
		}
	}

	/*
	 * Interval Delete Method
	 * removes node z, from the interval treap 
	 * This operation must maintain the required interval treap properties
	 * Runtime: O(logn) on an n-node interval treap
	 * 
	 */
	public void intervalDelete(Node z) {
		this.size--;

		while (z.getLeft() != null || z.getRight() != null) {
			if (z.getLeft() == null) 
			{
			    leftRotate(z);
			} 
			else if (z.getRight() == null) 
			{
			    rightRotate(z);
			} 
			else if (z.getLeft().getPriority() < z.getRight().getPriority()) 
			{
			    rightRotate(z);
			} 
			else 
			{
		            leftRotate(z);
			}
		}

		Transplant(z, null);  //Transplant method is used which is an additional method
		updateIMaxes(z.getParent());
		updateHeights(z.getParent());

		if (this.root != null) {
			this.height = this.root.getHeight();
		} else {
			this.height = 0;
		}
	}

	//Additional method
	private void Transplant(Node u, Node v) {
		if (u.getParent() == null) {
			this.root = v;
		} else if (u == u.getParent().getLeft()) {
			u.getParent().setLeft(v);
		} else {
			u.getParent().setRight(v);
		}
		if (v != null) {
			v.setParent(u.getParent());
		}
	}

	//Rotates a nodes right subtree left
	private void leftRotate(Node x) {
		Node w = x.getRight();
		w.setParent(x.getParent());
		if (w.getParent() != null) {
			if (w.getParent().getLeft() == x) {
				w.getParent().setLeft(w);
			} else {
				w.getParent().setRight(w);
			}
		}
		x.setRight(w.getLeft());
		if (x.getRight() != null) {
			x.getRight().setParent(x);
		}
		x.setParent(w);
		w.setLeft(x);
		if (x == this.root) {
			this.root = w;
			this.root.setParent(null);
		}

		x.setIMax(getIMax(x));
		w.setIMax(getIMax(w));
		x.setHeight(getHeight(x));
		w.setHeight(getHeight(w));
	}

	//Rotates a nodes left subtree to the right
	private void rightRotate(Node x) {
		Node w = x.getLeft();
		w.setParent(x.getParent());
		if (w.getParent() != null) {
			if (w.getParent().getLeft() == x) {
				w.getParent().setLeft(w);
			} else {
				w.getParent().setRight(w);
			}
		}
		x.setLeft(w.getRight());
		if (x.getLeft() != null) {
			x.getLeft().setParent(x);
		}
		x.setParent(w);
		w.setRight(x);
		if (x == this.root) {
			this.root = w;
			this.root.setParent(null);
		}

		x.setIMax(getIMax(x));
		w.setIMax(getIMax(w));
		x.setHeight(getHeight(x));
		w.setHeight(getHeight(w));
	}

	private void updateIMaxes(Node x) {
		while (x != null) {
			x.setIMax(getIMax(x));
			x = x.getParent();
		}
	}

	private void updateHeights(Node x) {
		while (x != null) {
			x.setHeight(getHeight(x));
			x = x.getParent();
		}
	}

	private int getIMax(Node x) {
		if (x.getLeft() == null && x.getRight() == null) {
			return x.getInterv().getHigh();
		} else if (x.getRight() == null) {
			return Math.max(x.getInterv().getHigh(), x.getLeft().getIMax());
		} else if (x.getLeft() == null) {
			return Math.max(x.getInterv().getHigh(), x.getRight().getIMax());
		} else {
			return Math.max(x.getInterv().getHigh(), Math.max(x.getLeft().getIMax(), x.getRight().getIMax()));
		}
	}

	/**
	 * Get Height Method
	 * Returns the height of the treap.
	 * Runtime: Constant
	 * 
	 **/
	private int getHeight(Node x) {
		if (x.getLeft() == null && x.getRight() == null) {
			return 0;
		} else if (x.getLeft() == null && x.getRight() != null) {
			return x.getRight().getHeight() + 1;
		} else if (x.getLeft() != null && x.getRight() == null) {
			return x.getLeft().getHeight() + 1;
		} else {
			return Math.max(x.getLeft().getHeight(), x.getRight().getHeight()) + 1;
		}
	}

	private Node minimum(Node x) {
		while (x.getLeft() != null) {
			x = x.getLeft();
		}
		return x;
	}

	public Node minimum() {
		return minimum(this.root);
	}

	/**
        * Returns a reference to a node x in the interval treap
        * such that x.interv overlaps interval i, or null if no such element is in the treap.
        * This method must not modify the interval treap. The expected running time of this method
        * should be O(log n) on an n-node interval treap.
        **/
	public Node intervalSearch(Interval i) {
		Node x = this.root;
		while (x != null && !i.overlaps(x.getInterv())) { // same keys (i.low) go as right children
			if (x.getLeft() != null && x.getLeft().getIMax() > i.getLow()) {
				x = x.getLeft();
			} else {
				x = x.getRight();
			}
		}
		return x;
	}

	// extra credit

	/**
	* Returns a reference to a Node object x
        * in the treap such that x.interv.low = i.low and x.interv.high = i.high, or null if
        * no such node exists. The expected running time of this method should be O(log n) on an
        * n-node interval treap. 
	**/
	public Node intervalSearchExactly(Interval i) {
		Node x = this.root;
		while (x != null) { // same keys (i.low) go as right children
			if (i.getLow() < x.getInterv().getLow()) {
				x = x.getLeft();
			} else if (i.getLow() > x.getInterv().getLow()) {
				x = x.getRight();
			} else {
				if (x.getInterv().getHigh() == i.getHigh()) {
					return x;
				} else {
					x = x.getRight();
				}
			}
		}
		return null;
	}

	//returns a list all intervals in the treap that overlap i.
	public List<Interval> overlappingIntervals(Interval i) {
		List<Interval> intervals = new ArrayList<Interval>();
		return intervals;
	}
}
