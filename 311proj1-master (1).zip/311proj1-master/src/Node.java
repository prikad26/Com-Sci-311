/**
 * Team members:
 * 
 * @author KayAnne Bryant
 * @author Priyanka Kadaganchi
 * 
 *  Node class represents the nodes of the treap. 
 */
import java.util.Random;

public class Node {
	 Node left;
	 Node right;
	 Node parent;
	 Interval interv;
	 int priority;
	 int height;
	 int imax;
	
	/**
	 * Constructor that takes an Interval i as its parameter.
	 * must generate a priority for the node.
	 * Therefore, after creation of a Node object,
	 * getPriority() must return the priority of this node.
	 * @param i
	 */
	public Node(Interval i) {
		this.interv = i;
		this.imax = i.getHigh();
		this.right = null;
		this.left = null;
		this.parent = null;
		Random rand = new Random();
		this.priority = rand.nextInt(1000000000);
		this.height = 0;
	}
	

	/**
	 * Returns the parent of this node.
	 * 
	 * @return
	 */
	public Node getParent() {
		return this.parent;
	}

	/**
	 * Returns the left child of this node.
	 * 
	 * @return
	 */
	public Node getLeft() {
		return this.left;
	}

	/**
	 * Returns the right child of this node.
	 * 
	 * @return
	 */
	public Node getRight() {
		return this.right;
	}

	/**
	 * Returns the interval object stored in this node.
	 * 
	 * @return
	 */
	public Interval getInterv() {
		return this.interv;
	}

	/**
	 * Returns the value of the imax field of this node.
	 * 
	 * @return
	 */
	public int getImax() {
		return this.imax;
	}

	/**
	 * Returns the priority of this node.
	 * 
	 * @return
	 */
	public int getPriority() {
		return this.priority;
	}
	
	/**
	 * Returns height of node
	 */
	public int getHeight() {
		return height;
	}
	
	/**
	 * Sets the left child of node
	 */
	public void setLeft(Node x) {
		this.left = x;
	}
	
	/**
	 * Sets the right child of node
	 */
	public void setRight(Node x) {
		this.right = x;
	}
	
	/**
	 * Sets the parent of node
	 */
	public void setParent(Node x) {
		this.parent = x;
	}
	
	/**
	 * Sets the imax value of node
	 */
	public void setImax(int i) {
		this.imax = i;
	}
	
	/**
	 * Sets the height of node
	 */
	public void setHeight(int i) {
		this.height = i;
	}
}
