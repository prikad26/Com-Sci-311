/**
 * Team members:
 * 
 * @author KayAnne Bryant
 * @author Priyanka Kadaganchi
 *
 *  The Interval class represents intervals.
 **/

public class Interval {
	private int low;
	private int high;

	// Constructor with two parameters: the low and high endpoints.
	public Interval(int low, int high) {
		this.low = low;
		this.high = high;
	}

	// Returns the low endpoint of the interval.
	public int getLow() {
		return this.low;
	}

	// Returns the high endpoint of the interval.
	public int getHigh() {
		return this.high;
	}

	//Overlaps method and uses a math function
	public boolean overlaps(Interval i) {
		return Math.max(this.low, i.getLow()) <= Math.min(this.high, i.getHigh());
	}

	@Override
	public boolean equals(Object o) {
		if (o == this) {
		return true;
		}
		if (!(o instanceof Interval)) {
		return false;
		}

		Interval i = (Interval) o;
		return (this.low == i.low && this.high == i.high);
	}
}
